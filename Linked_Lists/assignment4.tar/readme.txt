Author: Sankalp Patil
Date: 2/28/22


    This program allows the user to enter data stored as a linked list, have it sorted 
either in ascending or descending order, and quickly determine the number of prime 
numbers entered. 

    In addition, they are able to select what type of integer they would 
like to enter (signed or unsigned) which allows them to go beyond the usual 
limitations of signed integers, surpassing 2147483647 as the largest valid input. 
Furthermore, this program uses a recursive version of selection sort to sort the 
linked list in descending order. 
